/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        neonPink: '#FF00FF',
        neonBlue: '#00FFFF',
        neonPurple: '#9D00FF',
        neonGreen: '#00FFAA',
        cyberBlack: '#0B0C10',
        cyberGray: '#1F2833'
      },
      fontFamily: {
        cyber: ['Orbitron', 'sans-serif']
      }
    },
  },
  plugins: [],
}
