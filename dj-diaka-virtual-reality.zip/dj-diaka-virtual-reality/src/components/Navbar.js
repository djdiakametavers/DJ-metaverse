import React from 'react';
import { NavLink } from 'react-router-dom';

const links = [
  { name: 'Home', to: '/' },
  { name: 'About', to: '/about' },
  { name: 'Events', to: '/events' },
  { name: 'Merch', to: '/merch' },
  { name: 'Contact', to: '/contact' },
];

export default function Navbar() {
  return (
    <nav className="sticky top-0 z-50 bg-cyberGray backdrop-blur-md border-b border-neonPink/40">
      <ul className="flex justify-center space-x-8 p-4 font-bold text-neonPink text-lg">
        {links.map(({ name, to }) => (
          <li key={name}>
            <NavLink
              to={to}
              className={({ isActive }) =>
                isActive
                  ? 'text-neonBlue border-b-2 border-neonPink pb-1'
                  : 'hover:text-neonBlue transition-colors'
              }
            >
              {name}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}
