import React, { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stars, VRButton } from '@react-three/drei';
import { XR } from '@react-three/xr';

function NeonDJBooth({ audioAnalyser }) {
  const meshRef = useRef();

  // Audio-reactive scale based on frequency data
  useFrame(() => {
    if (!audioAnalyser) return;
    const dataArray = new Uint8Array(audioAnalyser.frequencyBinCount);
    audioAnalyser.getByteFrequencyData(dataArray);
    const avg = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
    const scale = 1 + avg / 256; // 1 to ~2 scale range
    meshRef.current.scale.set(scale, scale, scale);
    meshRef.current.rotation.y += 0.005;
  });

  return (
    <mesh ref={meshRef} position={[0, -1.5, 0]}>
      <boxGeometry args={[6, 1, 3]} />
      <meshStandardMaterial color="#ff00ff" emissive="#ff00ff" emissiveIntensity={1} />
    </mesh>
  );
}

export default function Home() {
  const [audioAnalyser, setAudioAnalyser] = useState(null);
  const audioRef = useRef();

  useEffect(() => {
    if (!audioRef.current) return;

    const audioCtx = new AudioContext();
    const source = audioCtx.createMediaElementSource(audioRef.current);
    const analyser = audioCtx.createAnalyser();
    source.connect(analyser);
    analyser.connect(audioCtx.destination);
    analyser.fftSize = 256;
    setAudioAnalyser(analyser);
  }, []);

  return (
    <>
      <div className="flex flex-col items-center gap-6 md:flex-row md:justify-center md:gap-16">
        <div className="w-full md:w-1/2 h-72 md:h-96 border-4 border-neonPink rounded-lg shadow-neonPink relative">
          <Canvas
            shadows
            camera={{ position: [0, 0, 8], fov: 45 }}
            className="rounded-lg"
          >
            <XR>
              <ambientLight intensity={0.3} />
              <pointLight position={[10, 10, 10]} intensity={2} color="#ff00ff" />
              <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade />
              <NeonDJBooth audioAnalyser={audioAnalyser} />
              <OrbitControls />
            </XR>
          </Canvas>
          <VRButton />
        </div>

        <div className="w-full md:w-1/2 flex flex-col gap-4">
          <h2 className="text-3xl font-bold text-neonBlue">Live DJ Diaka Stream</h2>
          <div className="aspect-video border-4 border-neonPink rounded-lg overflow-hidden shadow-neonPink">
            <iframe
              src="https://player.twitch.tv/?channel=djdiaka&parent=localhost"
              height="100%"
              width="100%"
              frameBorder="0"
              scrolling="no"
              allowFullScreen={true}
              title="DJ Diaka Twitch Stream"
              className="bg-black"
            ></iframe>
          </div>

          <audio
            ref={audioRef}
            src="https://cdn.pixabay.com/download/audio/2021/10/17/audio_9ae32fdb45.mp3?filename=techno-loop-9089.mp3"
            controls
            autoPlay
            loop
            className="mt-4 w-full"
          />
        </div>
      </div>
    </>
  );
}
