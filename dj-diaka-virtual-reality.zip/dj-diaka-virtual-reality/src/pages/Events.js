import React from 'react';

const events = [
  {
    date: '2025-07-15',
    title: 'MetaIranVerse Launch Party (VR Exclusive)',
    description: 'Join DJ Diaka in a full VR experience at the grand opening of MetaIranVerse!',
  },
  {
    date: '2025-08-01',
    title: 'Cyberpunk Neon Night Live Stream',
    description: 'A neon-lit virtual rave streamed live on Twitch.',
  },
  {
    date: '2025-08-20',
    title: 'Collaborative VR DJ Set with Special Guests',
    description: 'An immersive VR party with interactive music and visuals.',
  },
];

export default function Events() {
  return (
    <section className="max-w-4xl mx-auto p-6 bg-cyberGray rounded-lg shadow-neonPink">
      <h1 className="text-4xl font-bold mb-6 text-neonBlue">Upcoming Events</h1>
      <ul className="space-y-6">
        {events.map(({ date, title, description }) => (
          <li
            key={date + title}
            className="border-l-4 border-neonPink pl-4 hover:border-neonBlue transition-colors"
          >
            <time className="block font-semibold text-neonPink">{date}</time>
            <h2 className="text-2xl font-bold">{title}</h2>
            <p className="text-lg">{description}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
