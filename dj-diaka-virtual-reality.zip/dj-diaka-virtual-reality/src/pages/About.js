import React from 'react';

export default function About() {
  return (
    <section className="max-w-4xl mx-auto p-6 bg-cyberGray rounded-lg shadow-neonPink">
      <h1 className="text-4xl font-bold mb-4 text-neonBlue">About DJ Diaka</h1>
      <p className="text-lg leading-relaxed">
        DJ Diaka is a visionary electronic music artist blending cutting-edge technology with
        immersive experiences. With a passion for cyberpunk aesthetics and virtual reality,
        Diaka brings audiences a futuristic, neon-lit soundscape that pushes boundaries and
        elevates the art of DJing.
      </p>
      <p className="mt-4 text-lg leading-relaxed">
        From live VR performances to immersive online events, DJ Diaka is pioneering a new
        era of music entertainment where the digital world meets soulful beats.
      </p>
    </section>
  );
}
