import React, { useState } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleChange = e =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = e => {
    e.preventDefault();
    alert(`Thank you for contacting DJ Diaka, ${formData.name}! We'll get back to you soon.`);
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <section className="max-w-4xl mx-auto p-6 bg-cyberGray rounded-lg shadow-neonPink">
      <h1 className="text-4xl font-bold mb-6 text-neonBlue">Contact DJ Diaka</h1>
      <form onSubmit={handleSubmit} className="space-y-6">
        <input
          type="text"
          name="name"
          placeholder="Your Name"
          value={formData.name}
          onChange={handleChange}
          required
          className="w-full p-3 rounded bg-cyberBlack border border-neonPink focus:outline-none focus:ring-2 focus:ring-neonBlue text-neonPink"
        />
        <input
          type="email"
          name="email"
          placeholder="Your Email"
          value={formData.email}
          onChange={handleChange}
          required
          className="w-full p-3 rounded bg-cyberBlack border border-neonPink focus:outline-none focus:ring-2 focus:ring-neonBlue text-neonPink"
        />
        <textarea
          name="message"
          placeholder="Your Message"
          value={formData.message}
          onChange={handleChange}
          required
          rows="5"
          className="w-full p-3 rounded bg-cyberBlack border border-neonPink focus:outline-none focus:ring-2 focus:ring-neonBlue text-neonPink resize-none"
        ></textarea>
        <button
          type="submit"
          className="w-full py-3 bg-neonPink hover:bg-neonBlue transition-colors rounded font-bold text-cyberBlack"
        >
          Send
        </button>
      </form>
    </section>
  );
}
