import React from 'react';

export default function Merch() {
  return (
    <section className="max-w-4xl mx-auto p-6 bg-cyberGray rounded-lg shadow-neonPink text-center">
      <h1 className="text-4xl font-bold mb-6 text-neonBlue">Merch & NFTs</h1>
      <p className="text-lg mb-4">
        Coming soon: exclusive DJ Diaka NFTs and virtual goods to elevate your digital style.
      </p>
      <p className="italic text-sm text-neonPink">
        Stay tuned for futuristic merch drops in the MetaIranVerse universe!
      </p>
    </section>
  );
}
